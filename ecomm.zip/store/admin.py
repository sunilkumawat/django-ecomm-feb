from pyexpat import model
from django.contrib import admin

# Register your models here.
from .models import Categorie,Brand,Color,Product,FilterPrice,Tag,Images

@admin.register(Categorie)
class CategorieModel(admin.ModelAdmin):
    pass

@admin.register(Brand)
class BrandModel(admin.ModelAdmin):
    pass

@admin.register(Color)
class ColorModel(admin.ModelAdmin):
    pass

@admin.register(FilterPrice)
class FilterPriceModel(admin.ModelAdmin):
    pass

class TagModel(admin.TabularInline):
    model = Tag

class ImagesModel(admin.TabularInline):
    model = Images


class ProductModel(admin.ModelAdmin):
    inlines = (TagModel,ImagesModel)
    # list_display = ('unique_id','name','price','condition','stock','status','categorie','color')

admin.site.register(Product,ProductModel)
    




