from django.shortcuts import render,redirect
from store.models import Product
from django.db.models import Q


def base(request):
    return render(request,template_name='Main/base.html')


def home(request):
    product = Product.objects.filter(Q(stock='IN STOCK') & Q(condition='New') & Q(status='Publish'))
    context = {
        'product' :  product
    }
    return render(request,template_name='Main/index.html',context=context)
